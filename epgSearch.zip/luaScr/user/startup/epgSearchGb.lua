-- поиск на https://www.google.com из телепрограмы (14/3/20)
-- открывает браузер
	function findEPGInGb(epgId)
			if not epgId then return end
		local t = m_simpleTV.Database.GetTable('SELECT * FROM ChProg WHERE (ChProg.Id=' .. epgId .. ');')
			if not t
				or not t[1]
				or not t[1].Title
			then
			 return
			end
		m_simpleTV.Control.ExecuteAction(38, 0) -- SHOW_OSD_EPG
		-- local param = {text='epgID:' .. epgId .. '\n' .. 'Title:' .. t[1].Title,id='testEpgMenu'}
		-- m_simpleTV.OSD.ShowMessageT(param)
		local w = t[1].Title
		w = m_simpleTV.Common.toPersentEncoding(w)
		m_simpleTV.Interface.OpenLink('https://www.google.com/search?q=' .. w)
	end
	local t = {}
	t.utf8 = true
	t.name = 'Поиск в Google'
	t.lua_as_scr = true
	t.luastring = 'local action,param,extParam = ...;findEPGInGb(extParam)'
	t.location = 2 -- LOCATION_EPG_MENU
	t.image = m_simpleTV.Common.GetMainPath(0) .. 'Icons/menuG.png'
	m_simpleTV.Interface.AddExtMenuT(t)