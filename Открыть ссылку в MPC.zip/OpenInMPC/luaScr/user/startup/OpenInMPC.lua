-- дополнение "Открыть ссылку в MPC" (30/8/24)
-- Copyright © 2017-2024 Nexterr | https://github.com/Nexterr-origin/simpleTV-Addons
	function OpenInMPC()
		local shell = os.getenv('COMSPEC')
			if not shell then return end
		local tv = '"C:\\Programs\\MPC-BE\\mpc-be64.exe"' .. ' /play ' .. m_simpleTV.Control.RealAddress:gsub('$OPT:.+', '')
		local processid = m_simpleTV.Common.Execute(m_simpleTV.Common.multiByteToUTF8(shell), '/c start "" ' .. tv, 0x08000000)
			if not processid then return end
		m_simpleTV.Control.ExecuteAction(12)
	end
	local name
	if m_simpleTV.Interface.GetLanguage() == 'ru' then
		name = 'Открыть в MPC'
	else
		name = 'Open in MPC'
	end
	m_simpleTV.Interface.AddExtMenuT({
								name = name
								, luastring = 'OpenInMPC()'
								, lua_as_scr = true
								, ctrlkey = 1
								, key = 0x31
								, image = m_simpleTV.MainScriptDir_UTF8 .. 'user/OpenInMPC/img/mpc.ico'
								})
-- debug_in_file(tv .. '\n')