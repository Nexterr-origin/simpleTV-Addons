-- (18/12/20)
local function getConfigVal(key)
 return m_simpleTV.Config.GetValue(key,"LocalFilesConf.ini")
end
local function setConfigVal(key,val)
  m_simpleTV.Config.SetValue(key,val,"LocalFilesConf.ini")
end
function OnNavigateComplete(Object)
  local value
  value= getConfigVal("LocalFilesEnabledChk") or 0
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'LocalFilesEnabledChk',value)
  value= getConfigVal("LocalFilesVideoChk") or 1
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'LocalFilesVideoChk',value)
  value= getConfigVal("LocalFilesVideo") or 'ts,mp4,mkv,avi,wmv,iso'
  m_simpleTV.Dialog.SetElementValueString(Object,'LocalFilesVideo',value)
	value = getConfigVal('LocalFilesPlstsChk') or 1
	m_simpleTV.Dialog.SetCheckBoxValue(Object, 'LocalFilesPlstsChk', value)
	value = getConfigVal('LocalFilesDvdChk') or 1
	m_simpleTV.Dialog.SetCheckBoxValue(Object, 'LocalFilesDvdChk', value)
  value= getConfigVal("LocalFilesAudioChk") or 1
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'LocalFilesAudioChk',value)
  value= getConfigVal("LocalFilesAudio") or 'mp3,ogg,flac,wma'
  m_simpleTV.Dialog.SetElementValueString(Object,'LocalFilesAudio',value)
  value= getConfigVal("LocalFilesImageChk") or 1
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'LocalFilesImageChk',value)
  value= getConfigVal("LocalFilesImage") or 'gif,jpg,jpeg,png'
  m_simpleTV.Dialog.SetElementValueString(Object,'LocalFilesImage',value)
  value= getConfigVal("LocalFilesImageDur") or 5
  m_simpleTV.Dialog.SetElementValueString(Object,'LocalFilesImageDur',value)
  m_simpleTV.Dialog.AddEventHandler(Object,'OnClick','LocalFilesButtonDef','OnClickLocalFilesButtonDef')
end
------------------------------------------------------------------
function OnOk(Object)
local value
  value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'LocalFilesEnabledChk')
  if value~=nil then
      setConfigVal("LocalFilesEnabledChk",value)
      if tonumber(value)==1 then
         m_simpleTV.User.LocalFiles.isON=1
      else
         m_simpleTV.User.LocalFiles.isON=0
      end
  end
  value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'LocalFilesVideoChk')
  if value~=nil then
      setConfigVal("LocalFilesVideoChk",value)
      if tonumber(value)==1 then
         m_simpleTV.User.LocalFiles.isVideo=1
      else
         m_simpleTV.User.LocalFiles.isVideo=0
      end
  end
  value = m_simpleTV.Dialog.GetElementValueString(Object,'LocalFilesVideo')
  if value~=nil then
		setConfigVal("LocalFilesVideo",value)
		m_simpleTV.User.LocalFiles.Video=value
  end
	value = m_simpleTV.Dialog.GetCheckBoxValue(Object, 'LocalFilesPlstsChk')
	if value then
		setConfigVal('LocalFilesPlstsChk', value)
		if tonumber(value) == 1 then
			m_simpleTV.User.LocalFiles.isPlsts = 1
		else
			m_simpleTV.User.LocalFiles.isPlsts = 0
		end
	end
	value = m_simpleTV.Dialog.GetCheckBoxValue(Object, 'LocalFilesDvdChk')
	if value then
		setConfigVal('LocalFilesDvdChk', value)
		if tonumber(value) == 1 then
			m_simpleTV.User.LocalFiles.isDvd = 1
		else
			m_simpleTV.User.LocalFiles.isDvd = 0
		end
	end
  value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'LocalFilesAudioChk')
  if value~=nil then
      setConfigVal("LocalFilesAudioChk",value)
      if tonumber(value)==1 then
         m_simpleTV.User.LocalFiles.isAudio=1
      else
         m_simpleTV.User.LocalFiles.isAudio=0
      end
  end
  value = m_simpleTV.Dialog.GetElementValueString(Object,'LocalFilesAudio')
  if value~=nil then
		setConfigVal("LocalFilesAudio",value)
		m_simpleTV.User.LocalFiles.Audio=value
  end
  value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'LocalFilesImageChk')
  if value~=nil then
      setConfigVal("LocalFilesImageChk",value)
      if tonumber(value)==1 then
         m_simpleTV.User.LocalFiles.isImage=1
      else
         m_simpleTV.User.LocalFiles.isImage=0
      end
  end
  value = m_simpleTV.Dialog.GetElementValueString(Object,'LocalFilesImage')
  if value~=nil then
		setConfigVal("LocalFilesImage",value)
		m_simpleTV.User.LocalFiles.Image=value
  end
  value = m_simpleTV.Dialog.GetElementValueString(Object,'LocalFilesImageDur')
  if value~=nil then
		setConfigVal("LocalFilesImageDur",value)
		m_simpleTV.User.LocalFiles.ImageDuration=value
  end
end
------------------------------------------------------------------
function OnClickLocalFilesButtonDef(Object)
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'LocalFilesEnabledChk',0)
	m_simpleTV.Dialog.SetCheckBoxValue(Object, 'LocalFilesPlstsChk', 1)
	m_simpleTV.Dialog.SetCheckBoxValue(Object, 'LocalFilesDvdChk', 1)
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'LocalFilesVideoChk',1)
  m_simpleTV.Dialog.SetElementText(Object,'LocalFilesVideo','ts,mp4,mkv,avi,wmv,iso')
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'LocalFilesAudioChk',1)
  m_simpleTV.Dialog.SetElementText(Object,'LocalFilesAudio','mp3,ogg,flac,wma')
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'LocalFilesImageChk',1)
  m_simpleTV.Dialog.SetElementText(Object,'LocalFilesImage','gif,jpg,jpeg,png')
  m_simpleTV.Dialog.SetElementText(Object,'LocalFilesImageDur',5)
end
------------------------------------------------------------------