-- 5/12/20
-- LocalFiles
	local t = {}
	t.name = 'Local Files'
	t.htmlUri = m_simpleTV.MainScriptDir_UTF8 .. 'user/LocalFiles/configDialog.htm'
	t.luaUri  = 'user/LocalFiles/configDialog.lua'
	t.iconUri  = m_simpleTV.MainScriptDir_UTF8 .. 'user/LocalFiles/icon.png'
	m_simpleTV.Config.AddExtDialogT(t)