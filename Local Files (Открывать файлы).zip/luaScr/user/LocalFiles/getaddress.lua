-- 19/1/21
-- LocalFiles
		if m_simpleTV.Control.ChangeAddress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAddress_UTF8
		if not inAdr then return end
		if not inAdr:match('^.:') then return end
	if not m_simpleTV.User.LocalFiles.isON then
		m_simpleTV.User.LocalFiles.isON = 0
	end
	local isON = tonumber(m_simpleTV.User.LocalFiles.isON)
		if isON ~= 1 then return end
	if not m_simpleTV.User.LocalFiles.isVideo then
		m_simpleTV.User.LocalFiles.isVideo = 1
	end
	if not m_simpleTV.User.LocalFiles.isAudio then
		m_simpleTV.User.LocalFiles.isAudio = 1
	end
	if not m_simpleTV.User.LocalFiles.isImage then
		m_simpleTV.User.LocalFiles.isImage = 1
	end
	if not m_simpleTV.User.LocalFiles.isPlsts then
		m_simpleTV.User.LocalFiles.isPlsts = 1
	end
	if not m_simpleTV.User.LocalFiles.isDvd then
		m_simpleTV.User.LocalFiles.isDvd = 1
	end
	if not m_simpleTV.User.LocalFiles.ImageDuration then
		m_simpleTV.User.LocalFiles.ImageDuration = 5
	end
	local img_dur = m_simpleTV.User.LocalFiles.ImageDuration
	local extOpt = '$OPT:POSITIONTOCONTINUE=0$OPT:image-duration=' .. img_dur
	local set1, set2, set3 = '', '', ''
	if tonumber(m_simpleTV.User.LocalFiles.isVideo) == 1 then
		set1 = m_simpleTV.User.LocalFiles.Video or ''
		if set1 ~= '' and not set1:match('^.+,$') then
			set1 = set1 .. ','
		end
	end
	if tonumber(m_simpleTV.User.LocalFiles.isAudio) == 1 then
		set2 = m_simpleTV.User.LocalFiles.Audio or ''
		if set2 ~= '' and not set2:match('^.+,$') then
			set2 = set2 .. ','
		end
	end
	if tonumber(m_simpleTV.User.LocalFiles.isImage) == 1 then
		set3 = m_simpleTV.User.LocalFiles.Image or ''
		if set3 ~= '' and not set3:match('^.+,$') then
			set3 = set3 .. ','
		end
	end
	local set = set1 .. set2 .. set3
	local function trim(s)
	 return s:gsub('^%s*(.-)%s*$', '%1')
	end
	local ext = {}
		for w in set:gmatch('([^,]+)') do
			ext[#ext + 1] = trim(w)
		end
	local function CheckExt(suffix, tab_ext)
		for i, v in ipairs(tab_ext) do
			if string.lower(suffix) == string.lower(v) then return true end
		end
	 return false
	end
	local function filesTab(tab, adr, tab_ext)
		local index
		local t, i = {}, 1
			for j = 1, #tab do
				if not tab[j].isDir then
					if CheckExt(tab[j].suffix, tab_ext) then
						t[i] = {}
						t[i].Id = i
						t[i].Name = tab[j].fileName
						t[i].Address = 'file:///' .. tab[j].absoluteFilePath .. extOpt
						if not index and tab[j].absoluteFilePath == adr then
							index = i
						end
						i = i + 1
					end
				end
			end
	 return t, index
	end
	inAdr = inAdr:gsub('\\', '/')
	local path = inAdr:gsub('(.+)/.-$', '%1')
	local tab = m_simpleTV.Common.DirectoryEntryList(path)
		if not tab then return end
	local t, index = filesTab(tab, trim(inAdr), ext)
	if not index then
		if tonumber(m_simpleTV.User.LocalFiles.isPlsts) == 1 then
			local pl = {'m3u', 'm3u8', 'pls', 'dpl', 'asx', 'xspf', 'xml', 'kpl', 'zpl', 'aimppl4', 'mpcpl', 'tv'}
			local t, index = filesTab(tab, trim(inAdr), pl)
				if index then
					m_simpleTV.Control.CurrentAddress_UTF8 = t[index].Address:gsub('file:///(.-)$OPT:.-$', '%1')
					dofile(m_simpleTV.MainScriptDir .. 'user/LocalFiles/playlists.lua')
				 return
				end
		end
		if tonumber(m_simpleTV.User.LocalFiles.isDvd) == 1 then
			local dvd = {'ifo', 'bup', 'vob'}
			local t, index = filesTab(tab, trim(inAdr), dvd)
				if index then
					m_simpleTV.Control.CurrentAddress_UTF8 = t[index].Address:gsub('file:///(.-)$OPT:.-$', '%1')
					dofile(m_simpleTV.MainScriptDir .. 'user/LocalFiles/dvd.lua')
				 return
				end
		end
	 return
	end
	m_simpleTV.Control.ChangeAddress = 'Yes'
	local retAdr = t[index].Address
	local FilterType, AutoNumberFormat
	if #t > 5 then
		FilterType = 1
		AutoNumberFormat = '%1. %2'
	else
		FilterType = 2
		AutoNumberFormat = ''
	end
	t.ExtParams = {FilterType = FilterType, AutoNumberFormat = AutoNumberFormat}
	t.ExtButton0 = {ButtonEnable = true, ButtonName = '⚙', ButtonScript = 'm_simpleTV.Control.ExecuteAction(96)'}
	t.ExtButton1 = {ButtonEnable = true, ButtonName = 'ℹ️', ButtonScript = 'm_simpleTV.Control.ExecuteAction(65)'}
	m_simpleTV.OSD.ShowSelect_UTF8(path, index - 1, t, 30 * 1000, 512 + 32)
	m_simpleTV.Control.CurrentAddress_UTF8 = retAdr
-- debug_in_file(retAdr .. '\n')