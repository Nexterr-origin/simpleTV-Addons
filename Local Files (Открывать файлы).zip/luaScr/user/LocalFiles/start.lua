-- addon LocalFiles (17/1/22)
-- Copyright © 2017-2022 Nexterr | https://github.com/Nexterr-origin/simpleTV-Addons
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	if not m_simpleTV.User.LocalFiles then
		m_simpleTV.User.LocalFiles = {}
	end
	AddFileToExecute('getaddress', m_simpleTV.MainScriptDir .. 'user/LocalFiles/getaddress.lua')
	AddFileToExecute('onconfig', m_simpleTV.MainScriptDir .. 'user/LocalFiles/initconfig.lua')
	local function getConfigVal(key)
	 return m_simpleTV.Config.GetValue(key, 'LocalFilesConf.ini')
	end
	local value
	value=getConfigVal('LocalFilesEnabledChk')
	if value then
		if tonumber(value) == 1 then
			m_simpleTV.User.LocalFiles.isON = 1
		else
			m_simpleTV.User.LocalFiles.isON = 0
		end
	end
	value = getConfigVal('LocalFilesVideoChk')
	if value then
		if tonumber(value) == 1 then
			m_simpleTV.User.LocalFiles.isVideo = 1
		else
			m_simpleTV.User.LocalFiles.isVideo = 0
		end
	end
	value = getConfigVal('LocalFilesVideo')
	if value then
		m_simpleTV.User.LocalFiles.Video = value
	end
	value = getConfigVal('LocalFilesAudioChk')
	if value then
		if tonumber(value) == 1 then
			m_simpleTV.User.LocalFiles.isAudio = 1
		else
			m_simpleTV.User.LocalFiles.isAudio = 0
		end
	end
	value = getConfigVal('LocalFilesAudio')
	if value then
		m_simpleTV.User.LocalFiles.Audio = value
	end
	value = getConfigVal('LocalFilesImageChk')
	if value then
		if tonumber(value) == 1 then
			m_simpleTV.User.LocalFiles.isImage = 1
		else
			m_simpleTV.User.LocalFiles.isImage = 0
		end
	end
	value = getConfigVal('LocalFilesImage')
	if value then
		m_simpleTV.User.LocalFiles.Image = value
	end
	value = getConfigVal('LocalFilesImageDur')
	if value then
		m_simpleTV.User.LocalFiles.ImageDuration = value
	end
	value = getConfigVal('LocalFilesPlstsChk')
	if value then
		if tonumber(value) == 1 then
			m_simpleTV.User.LocalFiles.isPlsts = 1
		else
			m_simpleTV.User.LocalFiles.isPlsts = 0
		end
	end
	value = getConfigVal('LocalFilesDvdChk')
	if value then
		if tonumber(value) == 1 then
			m_simpleTV.User.LocalFiles.isDvd = 1
		else
			m_simpleTV.User.LocalFiles.isDvd = 0
		end
	end