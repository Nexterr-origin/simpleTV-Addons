-- 5/12/20
-- LocalFiles
dofile (m_simpleTV.MainScriptDir .. 'user/LocalFiles/start.lua')