-- addon LocalFiles (17/1/22)
-- Copyright © 2017-2022 Nexterr | https://github.com/Nexterr-origin/simpleTV-Addons
dofile (m_simpleTV.MainScriptDir .. 'user/LocalFiles/start.lua')