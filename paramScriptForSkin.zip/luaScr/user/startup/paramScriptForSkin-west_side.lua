-- paramScriptForSkin west_side (10/6/20)
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	local skinPath = tostring(m_simpleTV.Config.GetValue('skin/path', 'simpleTVConfig') or '')
	if skinPath:match('west_side') then
		skinPath = m_simpleTV.Common.GetMainPath(2) .. skinPath:gsub('^%./', '')
		m_simpleTV.User.paramScriptForSkin_logoYT = skinPath .. '/img/youtube.png'
		m_simpleTV.User.paramScriptForSkin_thumbsSizeFactor = 0.21
		m_simpleTV.User.paramScriptForSkin_thumbsBackColor = 0x00000000
		m_simpleTV.User.paramScriptForSkin_thumbsTextColor = 0xff1231f1
		m_simpleTV.User.paramScriptForSkin_thumbsMarginBottom = 25
		m_simpleTV.User.paramScriptForSkin_thumbsGlowParams = 'glow="7" samples="5" extent="4" color="0xB0F6F7F9"'
		m_simpleTV.User.paramScriptForSkin_buttonNext = skinPath .. '/img/osd/multiaddress/right.png'
		m_simpleTV.User.paramScriptForSkin_buttonPrev = skinPath .. '/img/osd/multiaddress/left.png'
		m_simpleTV.User.paramScriptForSkin_buttonOptions = skinPath .. '/img/osd/multiaddress/options.png'
		m_simpleTV.User.paramScriptForSkin_buttonInfo = skinPath .. '/img/osd/multiaddress/InfoButton.png'
		m_simpleTV.User.paramScriptForSkin_buttonSave = skinPath .. '/img/osd/multiaddress/saveplst.png'
		m_simpleTV.User.paramScriptForSkin_buttonPlst = skinPath .. '/img/osd/multiaddress/plst.png'
		m_simpleTV.User.paramScriptForSkin_buttonClose = skinPath .. '/img/osd/multiaddress/CloseButton.png'
		m_simpleTV.User.paramScriptForSkin_buttonSearch = skinPath .. '/img/osd/multiaddress/search.png'
		m_simpleTV.User.paramScriptForSkin_buttonOk = skinPath .. '/img/osd/multiaddress/select.png'
	end