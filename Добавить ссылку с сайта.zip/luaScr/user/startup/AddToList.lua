-- Скрипт для добавления адреса в плейлист из командной строки (29/2/20)
-- например: tv.exe -execute "AddFromCommandLine('Address', 'title')"
-- ## название группы
local GroupName = 'ссылки с сайтов'
-- '' - нет
-- ## проверять наличие в базе
local noCheck = 0
-- 0 - да
-- 1 - нет
-- ##
	local function findChannelIdByAddress(Address)
		if Address then
			local t = m_simpleTV.Database.GetTable('SELECT Channels.Id FROM Channels WHERE Channels.Address="' .. Address .. '" AND Channels.Id<268435455;')
				if t and t[1] and t[1].Id then
				 return t[1].Id
				end
		end
	 return
	end
	local function unescape_html(str)
		str = str:gsub('&#39;', '\'')
		str = str:gsub('&ndash;', '-')
		str = str:gsub('&#8217;', '\'')
		str = str:gsub('&raquo;', '"')
		str = str:gsub('&laquo;', '"')
		str = str:gsub('&lt;', '<')
		str = str:gsub('&gt;', '>')
		str = str:gsub('&quot;', '"')
		str = str:gsub('&apos;', '\'')
		str = str:gsub('&#(%d+);', function(n) return string.char(n) end)
		str = str:gsub('&#x(%d+);', function(n) return string.char(tonumber(n, 16)) end)
		str = str:gsub('&amp;', '&')
	 return str
	end
	local function clean_title(s)
		s = s:gsub('%%22', '\'')
		s = s:gsub('\\u0026', '&')
		s = s:gsub('\\u2060', '')
		s = s:gsub('\\n', ' ')
		s = unescape_html(s)
		s = s:gsub('"', '\'')
	 return s
	end
	local function GetInfoYT(adr)
		local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.2785.143 Safari/537.36')
			if not session then return end
		m_simpleTV.Http.SetTimeout(session, 5000)
		adr = 'http://www.youtube.com/oembed?format=xml&url=' .. adr
		local rc, answer = m_simpleTV.Http.Request(session, {url = adr})
		m_simpleTV.Http.Close(session)
			if rc ~= 200 then return end
		local logo = answer:match('<thumbnail_url>([^<]+)')
		local title = answer:match('<title>([^<]+)')
	 return title, logo
	end
	local function ShowMessage(s)
		m_simpleTV.OSD.ShowMessageT({text = s, showTime = 5000, id = 'channelName'})
	end
	function AddFromCommandLine(Address, title)
		local extFilter = 0
		local groupId = 0
		local typeMedia = m_simpleTV.PlayList.GetMediaMode();
		if GroupName ~= '' then
			local t = m_simpleTV.Database.GetTable('SELECT Channels.Id, Channels.ExtFilter,Channels.TypeMedia FROM Channels WHERE (Channels.Name="' .. GroupName .. '" AND Channels.Id>268435455);')
			if t and t[1] then
				groupId = (t[1].Id or 0)
				extFilter = (t[1].ExtFilter or 0)
				if t[1].TypeMedia then typeMedia = t[1].TypeMedia end
			end
		end
		local channelId
		if noCheck == 0 then
			channelId = findChannelIdByAddress(Address)
		end
		if channelId then
			if m_simpleTV.Interface.MessageBox('Адрес уже существует, переписать?', 'Добавление адреса', 0x24) ~= 6 then return end
			if not m_simpleTV.Database.ExecuteSql('DELETE FROM Channels WHERE (Channels.Id=' .. channelId .. ');', true) then return end
		else
			t = m_simpleTV.Database.GetTable('SELECT (MAX(Channels.Id))+1 AS NewId FROM Channels WHERE Channels.Id<268435456 AND Channels.Id<>268435455;')
				if not t or not t[1] or not t[1].NewId then return end
			channelId = t[1].NewId
		end
		local logo
		local logoYT, titleYT
		if Address:match('^https?://www%.youtube%.com/watch%?v=[^&]*$') then
			titleYT, logoYT = GetInfoYT(Address)
		end
		title = titleYT or title or Address
		title = clean_title(title)
		Address = Address:gsub('"', '%%22')
		logo = logoYT or ''
-- debug_in_file('channelId: ' .. channelId .. '\ntitle: ' .. title .. '\nAddress: ' .. Address .. '\ngroupId: ' .. groupId .. '\nextFilter: ' .. extFilter .. '\ntypeMedia: ' .. typeMedia .. '\nlogo: ' .. logo .. '\n\n')
		if m_simpleTV.Database.ExecuteSql('INSERT INTO Channels ([Id],[ChannelOrder],[Name],[Address],[Group],[Logo],[ExtFilter],[TypeMedia]) VALUES (' .. channelId .. ',' .. channelId .. ',"' .. title .. '","' .. Address .. '",' .. groupId .. ',"' .. logo .. '",' .. extFilter ..',' .. typeMedia .. ');')
		then
			m_simpleTV.PlayList.Refresh()
			ShowMessage('Адрес добавлен')
		else
			ShowMessage('не возможно добавить')
		end
	end