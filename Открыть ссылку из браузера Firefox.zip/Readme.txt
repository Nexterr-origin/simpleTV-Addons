25/4/23
#### Описание:
UserChromeFiles - это файлы JavaScript и CSS в профиле а также директории установки вашего Firefox
Этот метод основан на функции autoconfig настройки доступной в Firefox

Добавляет панели инсрументов:
Дополнительную панель
Вертикальную панель
Нижнюю панель
Некоторые нужные кнопки на панели
Special Widgets (интервылы и разделители) и Auto Hide Sidebar в виде доп. скриптов и стилей
В настройках UserChromeFiles (кнопка «Открыть настройки» или about:user-chrome-files)
можно настроить параметры панелей или отключить их

Также UserChromeFiles можно использовать как загрузчик скриптов и/или стилей
В папке custom_scripts находятся файлы JavaScript которые при необходимости можно подключить и/или добавить другие,
для детальной настройки смотрите CustomStylesScripts.jsm и CustomStylesScriptsChild.jsm
все дополнительные стили и скрипты подключаются в этих двух файлах, а также в интефейсе настроек UserChromeFiles
После изменения вами скриптов необходимо очистить кэш запуска Firefox
перезапустить кнопкой «Перезагрузка - ПКМ: Перезапустить и заново создать кэш быстрого запуска»,
или в настройках нажмите «Перезапустить*», и в about:support можно это сделать.
Многие скрипты для UserChromeFiles находятся на форуме https://forum.mozilla-russia.org/viewtopic.php?pid=792702#p792702
Папка custom_styles используется для различных файлов CSS которые подключаются там же где и скрипты
в CustomStylesScripts.jsm и CustomStylesScriptsChild.jsm ...

#### Установка для simpleTV:
1. Содержимое папки Firefox поместить в директорию установки Firefox.
2. Папку chrome поместить в директорию профиля Firefox, если профилей больше одного то можно добавить во все.
3. в файле ucf_contextmenuopenwith.js, скоректировать путь к tv.exe (по умолчанию C:\\simpleTV\\tv.exe)
	3.1 для версии Firefox 102+: в файле CustomStylesScripts.jsm, раскоментировать строку { path: "ucf_contextmenuopenwith.js", ucfobj: true, },
4. открыть в браузере: about:user-chrome-files, выставить галку только на «Для докум. окна браузера [ChromeOnly]»
5. нажать «Перезапустить*»
6. если в меню ПКМ пункты дублируются: в файле CustomStylesScripts.jsm, закоментировать строку
{ path: "ucf_contextmenuopenwith.js", ucfobj: true, },
в about:support очистить кэш запуска


