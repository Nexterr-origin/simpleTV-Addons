добавтяет пункт в меню Firefox 78-118 (27/9/23)

#### Установка для simpleTV:
1. Содержимое папки Firefox поместить в директорию установки Firefox.
2. Папку chrome поместить в директорию профиля Firefox
3. в файле ucf_contextmenuopenwith.js, скоректировать путь к tv.exe
4. запустить Firefox, открыть: about:support, нажать "очистить кэш запуска"

https://forum.mozilla-russia.org/viewtopic.php?id=76642