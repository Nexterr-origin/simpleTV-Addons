// Скрипт для документа окна браузера [ChromeOnly]
var ucf_custom_script_win = {
    initialized: false,
    get unloadlisteners() {
        delete this.unloadlisteners;
        window.addEventListener("unload", this, { once: true });
        return this.unloadlisteners = [];
    },
    load() {
        if (this.initialized)
            return;
        this.initialized = true;
        /* ************************************************ */

        // Здесь может быть ваш код который сработает по событию "load"
// скрипт contextmenuopenwith

(this.contextmenuopenwith = {
            _eventlisteners: [],
            menupage: {},
            menulink: {},
            init(that) {
                var attrimage = true; // true или false Добавить иконки (атрибут "image") или нет
                var submenu = true; // true или false Добавить подменю для пунктов или нет
                var prelabpage = true; // Добавить вначале "Открыть страницу в ";
                var prelablink = true; // Добавить вначале "Открыть ссылку в ";
                // [true или false Показывать пункт на странице или нет, true или false Показывать пункт на ссылках или нет, 'ID пункта', 'имя приложения', 'путь к приложению', 'аргументы через пробел (то что в двойных кавычках считается за один аргумент)', 'иконка (для ОС Windows необязательно)'],
                var arrayWindows = [ // для Windows
                    // [true, true, 'iexplore', 'IE', 'C:\\Program Files\\Internet Explorer\\iexplore.exe', '%OpenURI'],
                    // [true, true, 'edge', 'Microsoft Edge', 'C:\\Windows\\explorer.exe', '"microsoft-edge:%OpenURI "', 'moz-icon://file://C:\\Windows\\SystemApps\\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\\MicrosoftEdge.exe?size=16'],
                    // [true, true, 'potplayer', 'DAUM PotPlayer', 'C:\\Program Files\\DAUM\\PotPlayer\\PotPlayerMini64.exe', '%OpenURI'],
                    // [true, true, 'vlc', 'VLC', 'C:\\Program Files\\VideoLAN\\VLC\\vlc.exe', '%OpenURI'],
// для simpleTV - отредактировать путь
					[true, true, 'simpleTV', 'simpleTV', 'C:\\simpleTV\\tv.exe', '"%OpenURI"'],
                ];

                var arrayLinux = [ // для Linux
                    [true, true, 'smplayer', 'SMPlayer', '/usr/bin/smplayer', '%OpenURI', 'moz-icon://stock/smplayer?size=menu'],
                    [true, true, 'vlc', 'VLC', '/usr/bin/vlc', '%OpenURI', 'moz-icon://stock/vlc?size=menu'],
                    [true, true, 'uget', 'uGet', '/usr/bin/uget-gtk', '%OpenURI', 'moz-icon://stock/uget-icon?size=menu'],
                    [false, true, 'thunderbird', 'Thunderbird', '/usr/bin/thunderbird', '-compose "to=%OpenURI"', 'moz-icon://stock/thunderbird?size=menu'],
                    [true, true, 'youtube-dl', 'youtube-dl', '/usr/bin/konsole', '--hold --workdir ~/Загрузки/ -e "youtube-dl %OpenURI"', 'moz-icon://stock/youtube-dl?size=menu'], // если не KDE то konsole заменить на др. терминал и параметры соответственно.
                ];
                var arrayMacos = [ // для MacOS
                    [true, true, 'fde', 'Firefox Developer Edition', '/usr/bin/open', '-n -a "Firefox Developer Edition" --args %OpenURI', 'moz-icon://file:///Applications/Firefox\ Developer\ Edition.app?size=16'],
                    [true, true, 'mpv', 'MPV', '/usr/bin/open', '-n -a mpv --args %OpenURI', 'moz-icon://file:///Applications/mpv.app?size=16'],
                    [true, true, 'youtube-dl', 'youtube-dl', '/usr/bin/osascript', `-e "tell app %quotTerminal%quot to activate" -e "tell app %quotTerminal%quot to do script %quotcd ~/Downloads/ && youtube-dl '%OpenURI'%quot"`, 'moz-icon://file:///System/Applications/Utilities/Terminal.app?size=16'],
                ];

                var arrayOS, platform = AppConstants.platform, length;
                if (platform == "win")
                    arrayOS = arrayWindows;
                else if (platform == "linux")
                    arrayOS = arrayLinux;
                else if (platform == "macosx")
                    arrayOS = arrayMacos;
                else
                    return;
                if (!(length = arrayOS.length))
                    return;
                var addEventListener = this.addEventListener.bind(this);
                var popup = document.querySelector("#contentAreaContextMenu");
                var create = evt => {
                    if (evt.target != popup || gContextMenu.webExtBrowserType === "popup") return;
                    popup.removeEventListener("popupshowing", create);
                    var seppage = popup.querySelector("#context-sep-selectall") || popup.querySelector("#frame-sep") || popup.lastElementChild;
                    var seplink = popup.querySelector("#context-sep-copylink") || popup.querySelector("#context-sep-open") || popup.firstElementChild;
                    var fragpage = document.createDocumentFragment(), fraglink = document.createDocumentFragment(), _prelabpage = "", _prelablink = "";
                    if (length == 1)
                        submenu = false;
                    if (!submenu) {
                        if (prelabpage)
                            _prelabpage = "Открыть страницу в ";
                        if (prelablink)
                            _prelablink = "Открыть ссылку в ";
                    }
                    arrayOS.forEach(item => {
                        var id = item[2], name = item[3], path = item[4], arg = !item[5] ? "" : item[5];
                        if (!id || !name || !path) return;
                        var iconpath = !item[6] ? (`moz-icon://file://${path}?size=16`) : item[6];
                        if (item[0]) {
                            let menuitem_0 = document.createXULElement("menuitem");
                            menuitem_0.id = `open-current-page-with-${id}`;
                            menuitem_0.className = "menuitem-iconic open-current-page-with-application";
                            menuitem_0.setAttribute("label", `${_prelabpage}${name}`);
                            menuitem_0.applicationpath = path;
                            menuitem_0.applicationarg = arg;
                            if (attrimage)
                                menuitem_0.setAttribute("image", iconpath);
                            fragpage.append(menuitem_0);
                            addEventListener(menuitem_0, "command", function page(event) {
                                try {
                                    var target = event.currentTarget, arg = target.applicationarg, file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
                                    file.initWithPath(target.applicationpath);
                                    if (!file.exists() || !file.isExecutable()) return;
                                    arg = (arg !== "") ? arg.split(/\s+(?=(?:[^"]*"[^"]*")*[^"]*$)/g).map(sp => {
                                        if (/%OpenURI/g.test(sp)) {
                                            let uri = gBrowser.selectedBrowser.currentURI.displaySpec;
                                            try {
                                                let _uri = ReaderMode.getOriginalUrl(uri);
                                                if (_uri)
                                                    uri = Services.io.newURI(_uri).displaySpec;
                                            } catch(e) {}
                                            // try {
                                                // uri = decodeURIComponent(uri);
                                            // } catch(e) {}
                                            return sp.replace(/^"|"$/g, "").replace(/%quot/g, '"').replace(/%OpenURI/g, uri);
                                        }
                                        return sp.replace(/^"|"$/g, "").replace(/%quot/g, '"');
                                    }) : [];
                                    var process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
                                    process.init(file);
                                    process.runwAsync(arg, arg.length);
                                } catch(e) {}
                            });
                        }
                        if (item[1]) {
                            let menuitem_1 = document.createXULElement("menuitem");
                            menuitem_1.id = `open-link-with-${id}`;
                            menuitem_1.className = "menuitem-iconic open-link-with-application";
                            menuitem_1.setAttribute("label", `${_prelablink}${name}`);
                            menuitem_1.applicationpath = path;
                            menuitem_1.applicationarg = arg;
                            if (attrimage)
                                menuitem_1.setAttribute("image", iconpath);
                            fraglink.append(menuitem_1);
                            addEventListener(menuitem_1, "command", function link(event) {
                                try {
                                    var target = event.currentTarget, arg = target.applicationarg, file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
                                    file.initWithPath(target.applicationpath);
                                    if (!file.exists() || !file.isExecutable() || !window.gContextMenu?.linkURI?.displaySpec) return;
                                    arg = (arg !== "") ? arg.split(/\s+(?=(?:[^"]*"[^"]*")*[^"]*$)/g).map(sp => {
                                        if (/%OpenURI/g.test(sp)) {
                                            let uri = gContextMenu.linkURI.displaySpec;
                                            try {
                                                let _uri = ReaderMode.getOriginalUrl(uri);
                                                if (_uri)
                                                    uri = Services.io.newURI(_uri).displaySpec;
                                            } catch(e) {}
                                            // try {
                                                // uri = decodeURIComponent(uri);
                                            // } catch(e) {}
                                            return sp.replace(/^"|"$/g, "").replace(/%quot/g, '"').replace(/%OpenURI/g, uri);
                                        }
                                        return sp.replace(/^"|"$/g, "").replace(/%quot/g, '"');
                                    }) : [];
                                    var process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
                                    process.init(file);
                                    process.runwAsync(arg, arg.length);
                                } catch(e) {}
                            });
                        }
                    });
                    that.unloadlisteners.push("contextmenuopenwith");
                    var funcpopupshowing, funcpopuphiding;
                    if (!submenu) {
                        seppage.after(fragpage);
                        seplink.before(fraglink);
                        funcpopupshowing = () => {
                            var link = gContextMenu.onLink || gContextMenu.onMailtoLink;
                            for(let arr of this._eventlisteners) {
                                if (arr[2].name === "page")
                                    arr[0].hidden = link;
                                else if (arr[2].name === "link")
                                    arr[0].hidden = !link;
                            }
                        };
                        funcpopuphiding = () => {
                            for(let arr of this._eventlisteners) {
                                if (arr[1] === "command")
                                    arr[0].hidden = true;
                            }
                        };
                    } else {
                        if (fragpage.children.length) {
                            let menu = this.menupage = document.createXULElement("menu");
                            menu.id = "open-current-page-with-submenu";
                            menu.className = "menu-iconic open-current-page-with-application";
                            menu.setAttribute("label", "Открыть страницу в...");
                            let menupopup = document.createXULElement("menupopup");
                            menupopup.append(fragpage);
                            menu.append(menupopup);
                            seppage.after(menu);
                        }
                        if (fraglink.children.length) {
                            let menu = this.menulink = document.createXULElement("menu");
                            menu.id = "open-link-with-submenu";
                            menu.className = "menu-iconic open-link-with-application";
                            menu.setAttribute("label", "Открыть ссылку в...");
                            let menupopup = document.createXULElement("menupopup");
                            menupopup.append(fraglink);
                            menu.append(menupopup);
                            seplink.before(menu);
                        }
                        funcpopupshowing = () => {
                            var link = gContextMenu.onLink || gContextMenu.onMailtoLink;
                            this.menupage.hidden = link;
                            this.menulink.hidden = !link;
                        };
                        funcpopuphiding = () => {
                            this.menupage.hidden = true;
                            this.menulink.hidden = true;
                        };
                    }
                    funcpopupshowing();
                    addEventListener(popup, "popupshowing", e => {
                        if (e.target != popup || gContextMenu.webExtBrowserType === "popup") return;
                        funcpopupshowing();
                    });
                    addEventListener(popup, "popuphiding", e => {
                        if (e.target != popup) return;
                        funcpopuphiding();
                    });
                };
                popup.addEventListener("popupshowing", create);
            },
            addEventListener(...arr) {
                var elm = arr[0];
                if (!elm)
                    return;
                elm.addEventListener(...arr.slice(1));
                this._eventlisteners.push(arr);
            },
            destructor() {
                for(let arr of this._eventlisteners)
                    arr.shift().removeEventListener(...arr);
                delete this._eventlisteners;
            }
        }).init(this);
        /* ************************************************ */
    },
    handleEvent(e) {
        this[e.type](e);
    },
    unload() {
        this.unloadlisteners.forEach(str => {
            try {
                this[str].destructor();
            } catch (e) {}
        });
    },
};
/* ************************************************ */

// Здесь может быть ваш код который сработает по событию "DOMContentLoaded"
