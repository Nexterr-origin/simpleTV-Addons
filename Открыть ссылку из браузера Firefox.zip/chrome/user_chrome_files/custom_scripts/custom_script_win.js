// Этот скрипт работает в главном окне браузера если включено в настройках

var ucf_custom_script_win = {
    initialized: false,
    get unloadlisteners() {
        delete this.unloadlisteners;
        window.addEventListener("unload", this, { once: true });
        return this.unloadlisteners = [];
    },
    load() {
        if (this.initialized)
            return;
        this.initialized = true;
        // this.specialwidgets.init(); // <-- Special Widgets
        // this.autohidesidebar.init(); // <-- Auto Hide Sidebar
        /* ************************************************ */

        // Здесь может быть ваш код который сработает по событию "load" не раньше

(this.contextmenuopenwith = {
            _eventlisteners: [],
            init(that) {
                var attrimage = true; // true или false Добавить иконки (атрибут "image") или нет
                var submenu = false; // true или false Добавить подменю для пунктов или нет
                // [true или false Показывать пункт на странице или нет, true или false Показывать пункт на ссылках или нет, 'ID пункта', 'имя приложения', 'путь к приложению', 'аргументы через пробел (то что в двойных кавычках считается за один аргумент)', 'иконка (для ОС Windows необязательно)'],
                var arrayWindows = [ // для Windows
                    // [true, true, 'iexplore', 'IE', 'C:\\Program Files\\Internet Explorer\\iexplore.exe', '%OpenURI'],
                    // [true, true, 'edge', 'Microsoft Edge', 'C:\\Windows\\explorer.exe', '"microsoft-edge:%OpenURI "', 'moz-icon://file://C:\\Windows\\SystemApps\\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\\MicrosoftEdge.exe?size=16'],
                    // [true, true, 'potplayer', 'DAUM PotPlayer', 'C:\\Program Files\\DAUM\\PotPlayer\\PotPlayerMini64.exe', '%OpenURI'],
                    // [true, true, 'vlc', 'VLC', 'C:\\Program Files\\VideoLAN\\VLC\\vlc.exe', '%OpenURI'],
[true, true, 'simpleTV', 'simpleTV', 'C:\\simpleTV\\tv.exe', '"%OpenURI"'],						
                ];
                var arrayLinux = [ // для Linux
                    [true, true, 'smplayer', 'SMPlayer', '/usr/bin/smplayer', '%OpenURI', 'moz-icon://stock/smplayer?size=menu'],
                    [true, true, 'vlc', 'VLC', '/usr/bin/vlc', '%OpenURI', 'moz-icon://stock/vlc?size=menu'],
                    [true, true, 'uget', 'uGet', '/usr/bin/uget-gtk', '%OpenURI', 'moz-icon://stock/uget-icon?size=menu'],
                    [false, true, 'thunderbird', 'Thunderbird', '/usr/bin/thunderbird', '-compose "to=%OpenURI"', 'moz-icon://stock/thunderbird?size=menu'],
                ];
                var arrayMacos = [ // для MacOS
                    [true, true, 'fde', 'Firefox Developer Edition', '/usr/bin/open', '-n -a "Firefox Developer Edition" --args %OpenURI', 'moz-icon://file:///Applications/Firefox\ Developer\ Edition.app?size=16'],
                ];

                var arrayOS, platform = AppConstants.platform, length;
                if (platform == "win")
                    arrayOS = arrayWindows;
                else if (platform == "linux")
                    arrayOS = arrayLinux;
                else if (platform == "macosx")
                    arrayOS = arrayMacos;
                else
                    return;
                if (!(length = arrayOS.length))
                    return;
                var addEventListener = this.addEventListener.bind(this);
                var popup = document.querySelector("#contentAreaContextMenu");
                var seppage = popup.querySelector("#context-sep-selectall") || popup.querySelector("#frame-sep") || popup.lastElementChild;
                var seplink = popup.querySelector("#context-sep-copylink") || popup.querySelector("#context-sep-open") || popup.firstElementChild;
                var fragpage = document.createDocumentFragment(), fraglink = document.createDocumentFragment(), subpage = "", sublink = "";
                if (length == 1)
                    submenu = false;
                if (!submenu) {
                    subpage = "Открыть страницу в ";
                    sublink = "Открыть ссылку в ";
                }
                arrayOS.forEach(item => {
                    var id = item[2], name = item[3], path = item[4], arg = !item[5] ? "" : item[5];
                    if (!id || !name || !path) return;
                    var iconpath = !item[6] ? (`moz-icon://file://${path}?size=16`) : item[6];
                    if (item[0]) {
                        let menuitem_0 = document.createXULElement("menuitem");
                        menuitem_0.id = `open-current-page-with-${id}`;
                        menuitem_0.className = "menuitem-iconic open-current-page-with-application";
                        menuitem_0.setAttribute("label", `${subpage}${name}`);
                        if (!submenu)
                            menuitem_0.setAttribute("hidden", "true");
                        menuitem_0.applicationpath = path;
                        menuitem_0.applicationarg = arg;
                        if (attrimage)
                            menuitem_0.setAttribute("image", iconpath);
                        fragpage.append(menuitem_0);
                        addEventListener(menuitem_0, "command", function page(event) {
                            try {
                                var target = event.currentTarget, arg = target.applicationarg, file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
                                file.initWithPath(target.applicationpath);
                                if (!file.exists() || !file.isExecutable()) return;
                                arg = (arg !== "") ? arg.split(/\s+(?=(?:[^"]*"[^"]*")*[^"]*$)/g).map(sp => {
                                    if (/%OpenURI/g.test(sp)) {
                                        let uri = gBrowser.selectedBrowser.currentURI.displaySpec;
                                        try {
                                            let _uri = ReaderMode.getOriginalUrl(uri);
                                            if (_uri)
                                                uri = Services.io.newURI(_uri).displaySpec;
                                        } catch(e) {}
                                        // try {
                                            // uri = decodeURIComponent(uri);
                                        // } catch(e) {}
                                        return sp.replace(/^"|"$/g, "").replace("%OpenURI", uri);
                                    }
                                    return sp.replace(/^"|"$/g, "");
                                }) : [];
                                var process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
                                process.init(file);
                                process.runwAsync(arg, arg.length);
                            } catch(e) {}
                        });
                    }
                    if (item[1]) {
                        let menuitem_1 = document.createXULElement("menuitem");
                        menuitem_1.id = `open-link-with-${id}`;
                        menuitem_1.className = "menuitem-iconic open-link-with-application";
                        menuitem_1.setAttribute("label", `${sublink}${name}`);
                        if (!submenu)
                            menuitem_1.setAttribute("hidden", "true");
                        menuitem_1.applicationpath = path;
                        menuitem_1.applicationarg = arg;
                        if (attrimage)
                            menuitem_1.setAttribute("image", iconpath);
                        fraglink.append(menuitem_1);
                        addEventListener(menuitem_1, "command", function link(event) {
                            try {
                                var target = event.currentTarget, arg = target.applicationarg, file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
                                file.initWithPath(target.applicationpath);
                                if (!file.exists() || !file.isExecutable() || !window.gContextMenu?.linkURI?.displaySpec) return;
                                arg = (arg !== "") ? arg.split(/\s+(?=(?:[^"]*"[^"]*")*[^"]*$)/g).map(sp => {
                                    if (/%OpenURI/g.test(sp)) {
                                        let uri = gContextMenu.linkURI.displaySpec;
                                        try {
                                            let _uri = ReaderMode.getOriginalUrl(uri);
                                            if (_uri)
                                                uri = Services.io.newURI(_uri).displaySpec;
                                        } catch(e) {}
                                        // try {
                                            // uri = decodeURIComponent(uri);
                                        // } catch(e) {}
                                        return sp.replace(/^"|"$/g, "").replace("%OpenURI", uri);
                                    }
                                    return sp.replace(/^"|"$/g, "");
                                }) : [];
                                var process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
                                process.init(file);
                                process.runwAsync(arg, arg.length);
                            } catch(e) {}
                        });
                    }
                });
                that.unloadlisteners.push("contextmenuopenwith");
                if (!submenu) {
                    seppage.after(fragpage);
                    seplink.before(fraglink);
                    addEventListener(popup, "popupshowing", e => {
                        if (e.target != popup || gContextMenu.webExtBrowserType === "popup") return;
                        var link = gContextMenu.onLink || gContextMenu.onMailtoLink;
                        for(let arr of this._eventlisteners) {
                            if (arr[2].name === "page")
                                arr[0].hidden = link;
                            else if (arr[2].name === "link")
                                arr[0].hidden = !link;
                        }
                    });
                    addEventListener(popup, "popuphiding", e => {
                        if (e.target != popup) return;
                        for(let arr of this._eventlisteners) {
                            if (arr[1] === "command")
                                arr[0].hidden = true;
                        }
                    });
                } else {
                    let menu = this.menupage = document.createXULElement("menu");
                    menu.id = "open-current-page-with-submenu";
                    menu.className = "menu-iconic open-current-page-with-application";
                    menu.setAttribute("label", "Открыть страницу в...");
                    menu.setAttribute("hidden", "true");
                    let menupopup = document.createXULElement("menupopup");
                    menupopup.append(fragpage);
                    menu.append(menupopup);
                    seppage.after(menu);
                    menu = this.menulink = document.createXULElement("menu");
                    menu.id = "open-link-with-submenu";
                    menu.className = "menu-iconic open-link-with-application";
                    menu.setAttribute("label", "Открыть ссылку в...");
                    menu.setAttribute("hidden", "true");
                    menupopup = document.createXULElement("menupopup");
                    menupopup.append(fraglink);
                    menu.append(menupopup);
                    seplink.before(menu);
                    addEventListener(popup, "popupshowing", e => {
                        if (e.target != popup || gContextMenu.webExtBrowserType === "popup") return;
                        var link = gContextMenu.onLink || gContextMenu.onMailtoLink;
                        this.menupage.hidden = link;
                        this.menulink.hidden = !link;
                    });
                    addEventListener(popup, "popuphiding", e => {
                        if (e.target != popup) return;
                        this.menupage.hidden = true;
                        this.menulink.hidden = true;
                    });
                }
            },
            addEventListener(...arr) {
                var elm = arr[0];
                if (!elm)
                    return;
                elm.addEventListener(...arr.slice(1));
                this._eventlisteners.push(arr);
            },
            destructor() {
                for(let arr of this._eventlisteners)
                    arr.shift().removeEventListener(...arr);
                delete this._eventlisteners;
            }
        }).init(this);


        /* ************************************************ */
    },
    handleEvent(e) {
        this[e.type](e);
    },
    unload() {
        this.unloadlisteners.forEach(str => {
            try {
                this[str].destructor();
            } catch (e) {}
        });
    },
    specialwidgets: {
        _timer: null,
        get Customizable() {
            delete this.Customizable;
            if ("createSpecialWidget" in CustomizableUI)
                return this.Customizable = CustomizableUI;
            var scope = null;
            try {
                scope = Cu.import("resource:///modules/CustomizableUI.jsm", {}).CustomizableUIInternal;
            } catch (e) { }
            return this.Customizable = scope;
        },
        init() {
            if (!("CustomizableUI" in window) || !("gCustomizeMode" in window))
                return;
            ucf_custom_script_win.unloadlisteners.push("specialwidgets");
            window.addEventListener("customizationready", this);
        },
        destructor() {
            window.removeEventListener("customizationready", this);
        },
        handleEvent(e) {
            this[e.type](e);
        },
        customizationchange() {
            clearTimeout(this._timer);
            this._timer = setTimeout(() => {
                this.createSpecialWidgets();
            }, 1000);
        },
        customizationready() {
            if (!this.Customizable)
                return;
            this.createSpecialWidgets();
            window.addEventListener("customizationchange", this);
            window.addEventListener("customizationending", this);
        },
        customizationending() {
            window.removeEventListener("customizationchange", this);
            window.removeEventListener("customizationending", this);
        },
        createSpecialWidgets() {
            try {
                let fragment = document.createDocumentFragment();
                if (this.findSpecialWidgets("spring")) {
                    let spring = this.Customizable.createSpecialWidget("spring", document);
                    spring.setAttribute("label", "Растягивающийся интервал");
                    fragment.append(gCustomizeMode.wrapToolbarItem(spring, "palette"));
                }
                if (this.findSpecialWidgets("spacer")) {
                    let spacer = this.Customizable.createSpecialWidget("spacer", document);
                    spacer.setAttribute("label", "Интервал");
                    fragment.append(gCustomizeMode.wrapToolbarItem(spacer, "palette"));
                }
                if (this.findSpecialWidgets("separator")) {
                    let separator = this.Customizable.createSpecialWidget("separator", document);
                    separator.setAttribute("label", "Разделитель");
                    fragment.append(gCustomizeMode.wrapToolbarItem(separator, "palette"));
                }
                gCustomizeMode.visiblePalette.append(fragment);
            } catch (e) {}
        },
        findSpecialWidgets(string) {
            try {
                if (!gCustomizeMode.visiblePalette.querySelector(`toolbar${string}[id^="customizableui-special-${string}"]`))
                    return true;
            } catch (e) {}
            return false;
        }
    },
    autohidesidebar: {
        events: ["dragenter", "drop", "dragexit", "MozLayerTreeReady"],
        init() {
            var sidebar = this.sidebar = document.querySelector("#sidebar-box");
            if (!sidebar) return;
            for (let type of this.events)
                sidebar.addEventListener(type, this);
            ucf_custom_script_win.unloadlisteners.push("autohidesidebar");
            var popup = this.popup = document.querySelector("#sidebarMenu-popup");
            if (!popup) return;
            popup.addEventListener("popupshowing", this);
        },
        destructor() {
            var sidebar = this.sidebar;
            for (let type of this.events)
                sidebar.removeEventListener(type, this);
            if (!this.popup) return;
            this.popup.removeEventListener("popupshowing", this);
        },
        handleEvent(e) {
            this[e.type](e);
        },
        MozLayerTreeReady(e) {
            if (e.originalTarget?.id == "webext-panels-browser" && !this.sidebar.hasAttribute("sidebardrag")) {
                window.addEventListener("mousedown", () => {
                    this.drop();
                }, { once: true });
                this.dragenter();
            }
        },
        popupshowing() {
            this.popup.addEventListener("popuphidden", () => {
                this.drop();
            }, { once: true });
            this.dragenter();
        },
        dragenter() {
            if (!this.sidebar.hasAttribute("sidebardrag"))
                this.sidebar.setAttribute("sidebardrag", "true");
        },
        drop() {
            if (this.sidebar.hasAttribute("sidebardrag"))
                this.sidebar.removeAttribute("sidebardrag");
        },
        dragexit(e) {
            var sidebar = this.sidebar;
            var boxObj = sidebar.getBoundingClientRect(), boxScrn = !sidebar.boxObject ? sidebar : sidebar.boxObject;
            if ((!e.relatedTarget || e.screenY <= (boxScrn.screenY + 5) || e.screenY  >= (boxScrn.screenY + boxObj.height - 5)
                || e.screenX <= (boxScrn.screenX + 5) || e.screenX >= (boxScrn.screenX + boxObj.width - 5))
                && sidebar.hasAttribute("sidebardrag"))
                sidebar.removeAttribute("sidebardrag");
        }
    },
};

if (window.document.readyState != "complete") {
    window.addEventListener("load", function load() {
        ucf_custom_script_win.load();
    }, { once: true });
} else
    ucf_custom_script_win.load();
