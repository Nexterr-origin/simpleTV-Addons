-- (22/1/20)
	function OpenNewInstance()
		local shell = os.getenv('COMSPEC')
			if not shell then return end
		local tv = '"' .. m_simpleTV.Common.GetMainPath(2) .. 'tv.exe"' .. ' -awaymode'
		-- local tv = '"' .. m_simpleTV.Common.GetMainPath(2) .. 'tv.exe"' .. ' -awaymode -qtsoftwareopengl'
		local processid = m_simpleTV.Common.Execute(m_simpleTV.Common.string_toUTF8(shell), '/c start "" ' .. tv, 0x08000000)
			if not processid then return end
	end
	local name
	if m_simpleTV.Interface.GetLanguage() == 'ru' then
		name = 'Открыть копию'
	else
		name = 'Open New Instance'
	end
	m_simpleTV.Interface.AddExtMenuT({
								name = name
								, luastring = 'OpenNewInstance()'
								, lua_as_scr = true
								, ctrlkey = 2
								, key = 0x39
								, image = m_simpleTV.MainScriptDir_UTF8 .. 'user/OpenNewInstance/img/tvgreen.png'
								})
-- debug_in_file(tv .. '\n')