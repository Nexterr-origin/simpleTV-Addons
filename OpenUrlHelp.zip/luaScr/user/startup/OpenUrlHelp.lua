-- OpenUrlHelp (9/12/20)
-- Copyright © 2017-2020 Nexterr | https://github.com/Nexterr/simpleTV
	local youtube = true
	local kinopoisk = true
	local acestream = true
	local function yt(chk)
			if not chk then return '' end
		local video, playlist, channel, live
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			video = 'видео'
			playlist = 'плейлист'
			channel = 'канал'
			live = 'прямая трансляция'
		else
			video = 'video'
			playlist = 'playlist'
			channel = 'channel'
			live = 'live'
		end
	 return '<p><strong>YouTube</strong></p><table border="1"><tr><td>&nbsp;<strong>- ' .. video .. '</strong>&nbsp;</td><td>&nbsp;<strong>-- ' .. playlist .. '</strong>&nbsp;</td></tr><tr><td>&nbsp;<strong>--- ' .. channel .. '</strong>&nbsp;</td><td>&nbsp;<strong>-+ ' .. live .. '</strong>&nbsp;</td></tr></table>'
	end
	local function kp(chk)
			if not chk then return '' end
		local title, name
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			title = 'КиноПоиск'
			name = 'название'
		else
			title = 'KinoPoisk'
			name = 'name'
		end
	 return '<p><strong>' .. title .. '</strong></p><table border="1"><tr><td>&nbsp;<strong>* ' .. name .. '</strong>&nbsp;</td><td>&nbsp;<strong>** ID</strong>&nbsp;</td></tr></table>'
	end
	local function as(chk)
			if not chk then return '' end
		local name
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			name = 'название'
		else
			name = 'name'
		end
	 return '<p><strong>AceStream</strong></p><table border="1"><tr><td>&nbsp;<strong>+ ' .. name ..'</strong>&nbsp;</td></tr></table>'
	end
	local function strHtml(html)
		local search
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			search = 'поиск'
		else
			search = 'search'
		end
	 return '<html><body><h3>🔎 ' .. search .. '</h3><p></p>' .. html .. '</body></html>'
	end
	local str = yt(youtube) .. kp(kinopoisk) .. as(acestream)
		if str == '' then return end
	str = strHtml(str)
	m_simpleTV.PlayList.SetOpenUrlHelp(str)