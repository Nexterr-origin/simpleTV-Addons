-- Скрипт для быстрого добавления текущего адреса в плейлист 26/5/22
-- Copyright © 2017-2022 Nexterr | https://github.com/Nexterr-origin/simpleTV-Addons
-------------------------------------------------------------------------------------------
local GroupName = '' -- название группы, '' - нет
-------------------------------------------------------------------------------------------
	local function CleanTitle(s, adr)
		if not adr:match('/videos') then
			s = s:gsub('^Загруженные на ', '')
		end
		s = s:gsub('^https?://', '')
		s = s:gsub('%- YouTube', '')
		s = s:gsub('^%d.-%.', '')
		s = s:gsub('"', '""')
		s = s:gsub('%s+', ' ')
		s = s:gsub('^%s*', '')
		s = s:gsub('%s*$', '')
	 return s
	end
	local function CleanAdr(s)
		s = s:gsub('&is%a+=%a+', '')
		s = s:gsub('$OPT.+', '')
		s = s:gsub('^file:///', '')
	 return s
	end
	local function findChannelIdByAddress(adr)
		if adr then
			local t = m_simpleTV.Database.GetTable('SELECT Channels.Id FROM Channels WHERE Channels.Address="' .. adr .. '" AND Channels.Id<268435455;')
				if t and t[1] and t[1].Id then return t[1].Id end
		end
	 return nil
	end
	function AddCurrentAddressToPlaylist()
		local info = m_simpleTV.Control.GetCurrentChannelInfo()
			if not info or info.Id == - 1 then return end
		local title = info.ExtTitle
		if not title then
			if info.MultiChangeTitle == true then
				title = (info.MultiName or info.Title)
			else
				title = info.Title
			end
		end
		local pos = (m_simpleTV.Control.GetPosition() or 0)
		local adr
		local askOnMultiaddress = true
		if askOnMultiaddress and not findChannelIdByAddress(info.Address) then
			adr = info.Address
			if info.MultiAddress and info.MultiAddress ~= '' then
				local ret =  m_simpleTV.Interface.MessageBox('Добавить адрес плейлиста?\n[нет] - ролика', 'Добавление канала', 0x23)
					if ret == 2 then return end
				if ret == 6 then
					if info.MultiHeader then title = info.MultiHeader end
					pos = 0
				else
					adr = info.MultiAddress
				end
			end
		else
			adr = (info.MultiAddress or	info.Address)
		end
			if not adr then return end
		adr = CleanAdr(adr)
		if not title then title = adr end
		title = CleanTitle(title, adr)
		local extFilter = 0
		local groupId = 0
		local typeMedia = m_simpleTV.PlayList.GetMediaMode();
		if GroupName ~= '' then
			local t = m_simpleTV.Database.GetTable('SELECT Channels.Id, Channels.ExtFilter,Channels.TypeMedia FROM Channels WHERE (Channels.Name="' ..   GroupName .. '" AND Channels.Id>268435455);')
			if t and t[1] then
				groupId = (t[1].Id or 0)
				extFilter = (t[1].ExtFilter or 0)
				if t[1].TypeMedia then typeMedia = t[1].TypeMedia end
			end
		end
		local channelId = findChannelIdByAddress(adr)
		if channelId then
				if m_simpleTV.Interface.MessageBox('Канал с таким адресом уже существует, переписать?', 'Добавление канала', 0x24) ~= 6 then return end
				if not m_simpleTV.Database.ExecuteSql('DELETE FROM Channels WHERE (Channels.Id=' .. channelId .. ');', true) then return end
		else
			t = m_simpleTV.Database.GetTable('SELECT (MAX(Channels.Id))+1 AS NewId FROM Channels WHERE Channels.Id<268435456 AND Channels.Id<>268435455;')
				if not t or not t[1] or not t[1].NewId then return end
			channelId = t[1].NewId
		end
-- debug_in_file('id:' .. channelId ..  '\ntitle:' .. title .. '\nadr:' .. adr .. '\ngr:' .. groupId .. '\npos:' .. pos .. '\n')
		if m_simpleTV.Database.ExecuteSql('INSERT INTO Channels ([Id],[ChannelOrder],[Name],[Address],[Group],[ExtFilter],[TypeMedia],[LastPosition]) VALUES (' .. channelId .. ',' .. channelId .. ',"' .. title .. '","' .. adr .. '",' .. groupId .. ',' .. extFilter ..',' .. typeMedia .. ',' .. pos .. ');') then
			m_simpleTV.PlayList.Refresh()
			m_simpleTV.OSD.ShowMessageT({text = 'Канал добавлен', color = 0xff9999ff})
		end
	end
	m_simpleTV.Interface.AddExtMenuT({name = 'Добавить в плейлист', luastring= 'AddCurrentAddressToPlaylist()',lua_as_scr = true, ctrlkey = 2, key = 0x51, image = m_simpleTV.Common.GetMainPath(2) .. 'skin\\base\\img\\programme\\refresh.png'})
	m_simpleTV.Interface.AddExtMenuT({utf8 = false, name = '-'})