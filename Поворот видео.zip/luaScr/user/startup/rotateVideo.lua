-- поворот видео на 90° (21/11/21)
-- Copyright © 2017-2021 Nexterr | https://github.com/Nexterr-origin/simpleTV-Addons
	local t = {}
		t.utf8 = true
		t.name = 'Поворот видео на 90°'
		t.lua_as_scr = true
		t.luastring = 'if m_simpleTV.Control.GetState() == 3 or m_simpleTV.Control.GetState() == 4 then m_simpleTV.Control.SetNewAddressT({address = m_simpleTV.Control.RealAddress .. "$OPT:video-filter=transform$OPT:transform-type=90"}) end'
		t.key = string.byte('R')
		t.ctrlkey = 2
		m_simpleTV.Interface.AddExtMenuT(t)