-- поворот видео на 90° (23/11/21)
-- Copyright © 2017-2021 Nexterr | https://github.com/Nexterr-origin/simpleTV-Addons
	local t = {}
		t.utf8 = true
		t.name = 'Поворот видео на 90°'
		t.lua_as_scr = true
		t.luastring =
		[[
		if m_simpleTV.Control.IsVideo()
			and m_simpleTV.Control.MainMode == 0
		then
			local adr = m_simpleTV.Common.multiByteToUTF8(m_simpleTV.Control.RealAddress)
			local opt = '$OPT:video%-filter=transform$OPT:transform%-type=90'
			if m_simpleTV.Common.multiByteToUTF8(m_simpleTV.Control.RealAddress):match(opt)
				or m_simpleTV.Control.CurrentAddress:match(opt)
			then
				adr = adr:gsub(opt, '')
			else
				adr = adr .. opt:gsub('%%', '')
			end
			m_simpleTV.Control.SetNewAddressT({address = adr, position = m_simpleTV.Control.GetPosition()})
		end
		]]
		t.key = string.byte('R')
		t.ctrlkey = 2
		m_simpleTV.Interface.AddExtMenuT(t)